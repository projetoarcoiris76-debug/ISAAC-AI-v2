/*
1. Troque TROQUE_PELA_SUA_SENHA pela senha escolhida.
2. Para conectar sua IA, informe o endereço do servidor em API_URL.
Não coloque chaves secretas neste arquivo público.
*/
const DEMO_PASSWORD = "TROQUE_PELA_SUA_SENHA";
const API_URL = ""; // Ex.: https://seu-servico.onrender.com/chat

const loginScreen=document.getElementById("loginScreen");
const loginForm=document.getElementById("loginForm");
const passwordInput=document.getElementById("password");
const togglePassword=document.getElementById("togglePassword");
const loginError=document.getElementById("loginError");
const app=document.getElementById("app");
const logoutBtn=document.getElementById("logoutBtn");
const chatForm=document.getElementById("chatForm");
const userInput=document.getElementById("userInput");
const chatMessages=document.getElementById("chatMessages");
const chatStatus=document.getElementById("chatStatus");

togglePassword.addEventListener("click",()=>{
  const show=passwordInput.type==="password";
  passwordInput.type=show?"text":"password";
  togglePassword.setAttribute("aria-label",show?"Ocultar senha":"Mostrar senha");
});
loginForm.addEventListener("submit",event=>{
  event.preventDefault();
  if(passwordInput.value===DEMO_PASSWORD){
    loginError.textContent="";
    loginScreen.classList.add("hidden");
    app.classList.remove("hidden");
    userInput.focus();
  }else{
    loginError.textContent="Senha incorreta. Tente novamente.";
    passwordInput.select();
  }
});
logoutBtn.addEventListener("click",()=>{
  app.classList.add("hidden");
  loginScreen.classList.remove("hidden");
  passwordInput.value="";
  loginError.textContent="";
  passwordInput.focus();
});
function addMessage(text,who){
  const bubble=document.createElement("div");
  bubble.className="message "+(who==="user"?"user-message":"zak-message");
  const label=document.createElement("strong");
  label.textContent=who==="user"?"VOCÊ":"ZAK";
  const paragraph=document.createElement("p");
  paragraph.textContent=text;
  bubble.append(label,paragraph);
  chatMessages.appendChild(bubble);
  bubble.scrollIntoView({behavior:"smooth",block:"nearest"});
}
chatForm.addEventListener("submit",async event=>{
  event.preventDefault();
  const message=userInput.value.trim();
  if(!message)return;
  addMessage(message,"user");
  userInput.value="";
  userInput.focus();
  if(!API_URL){
    addMessage("A tela está funcionando, mas a IA ainda não está conectada. Configure API_URL no app.js com o endereço e o formato esperado pelo seu servidor.","zak");
    chatStatus.textContent="Servidor da IA não configurado.";
    return;
  }
  chatStatus.textContent="ZAK está pensando...";
  try{
    const response=await fetch(API_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message})});
    if(!response.ok)throw new Error("HTTP "+response.status);
    const data=await response.json();
    addMessage(String(data.reply??data.response??data.message??"Não encontrei o texto da resposta do servidor."),"zak");
    chatStatus.textContent="Conectado ao servidor.";
  }catch(error){
    addMessage("Não consegui falar com o servidor. Confira o endereço da API e se ele está online.","zak");
    chatStatus.textContent="Falha de conexão com a IA.";
  }
});
